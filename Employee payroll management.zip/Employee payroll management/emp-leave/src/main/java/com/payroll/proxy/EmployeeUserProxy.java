package com.payroll.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.payroll.entity.Employee;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="emp-user") 
public interface EmployeeUserProxy {
	
	@Retry(name = "emp-user")
	@CircuitBreaker(name="emp-user", fallbackMethod="fallbackMethodForGetEmployeeById")
	@GetMapping(value ="/employee/{id}", produces = {MediaType.APPLICATION_JSON_VALUE}) 
	public Employee getEmployeeById(@PathVariable("id") Integer id);

	public default Employee fallbackMethodForGetEmployeeById(Integer id, Throwable cause) {
		System.out.println("Exception raised with message: ===> " + cause.getMessage());
		Employee fallbackEmployee = new Employee(id, "Fall Back Employee", "Application Down", "Error",
				 "Application Down", "Error","Application Down", "Error");
		return fallbackEmployee;
	}
}